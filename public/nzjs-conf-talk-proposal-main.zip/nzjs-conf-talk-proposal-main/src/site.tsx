import { h } from "./h";
import { SiteContents } from "./contents";
import { createFragment } from '@opennetwork/vdom';

//
// export const SiteHead = (
//   <fragment>
//     <title>VGraph</title>
//     <link href="index.css" rel="stylesheet" type="text/css" />
//     <meta name="viewport" content="width=device-width, initial-scale=1" />
//   </fragment>
// );

export const SiteBody = <SiteContents />
