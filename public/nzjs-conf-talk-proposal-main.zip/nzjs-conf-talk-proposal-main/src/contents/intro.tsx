import { h } from '../h';
import { createFragment } from '@opennetwork/vnode';
import { Goals } from './goals';
import { Template } from '../template';

export const Intro = (
  <>
    <Template id="intro-template">
      <h1>A fresh take on JSX components</h1>
      <div class="quote">
        Deterministic rendering of async JSX components made possible by grouping async
        tasks on the microtask level, removing the need for additional core heuristics
        relating to when rendering should take place.
      </div>
    </Template>
    {Goals}
  </>
)
