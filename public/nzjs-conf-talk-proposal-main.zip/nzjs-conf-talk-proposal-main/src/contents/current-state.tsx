import { h } from "../h";

export const CurrentState = (
  <section id="current-state">
    <h4>Current project state</h4>
    <p>

    </p>
  </section>
)
