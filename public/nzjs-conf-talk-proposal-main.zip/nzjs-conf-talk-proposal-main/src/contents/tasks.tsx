import { h } from "../h";
import { Template } from '../template';

export const Tasks = (
  <Template id="tasks-template">
    <section id="tasks">
      <h2>
        <a href="https://developer.mozilla.org/en-US/docs/Web/API/HTML_DOM_API/Microtask_guide">Microtasks</a>
        {" (Optional, More in depth details)"}
      </h2>
      <p>
        This pattern leans heavily on being able to sets tasks of work together.
      </p>
      <p>
        Because we treat the producing code as a black box we have to make some
        up-front assumptions.
      </p>
      <p>
        The biggest assumption that is made in these
        patterns is that optimization has already been completed before the value
        is read by a consumer, whether it was manual code optimization by
        a developer, bundler optimization, or platform optimization. This allows
        consuming patterns to focus on their sole tasks rather than focusing on
        un-related functionality just to get the job done.
      </p>
      <h4>Batching Promises</h4>
      <p>
        Given this we can make a secondary assumption, that if a promise hasn't
        resolved in the same microtask, then it will resolve in a later one.
      </p>
      <p>
        We can represent this statement using this code:
      </p>
      <pre>
      {`
async function resolveNextPromises<T>(input: Promise<T>[], task = queueMicrotask): Promise<[Promise<T>, T][]> {
  if (!input.length) {
    return [];
  }
  
  // Create a target for inflight promises to add values to
  // We will return a static snapshot of this
  const results: [Promise<T>, T][] = [];
  
  // Map all our promises to a new promise that is resolved _after_ we add our result
  const promises = input.map(async (promise): Promise<void> => {
    const value = await promise;
    results.push([promise, value]);
  });
  
  // We are waiting for either all promises to resolve
  // or for the next task
  //
  // If any promise throws we will reject here
  await Promise.any<unknown>([
    new Promise<void>(task),
    Promise.all(promises)
  ]);
  
  // If we didn't get any results within our microtask, wait until at least one
  // result is available
  if (!results.length) {
    await Promise.any(promises);
  }
  
  // Take a static snapshot of the results, any added after this
  // will be discarded
  return [...results];
}
      `.trim()
      }
    </pre>
      <p>
        Utilising the above we can batch sets of promises together to produce a
        single result set, without any knowledge of internal states at the
        smallest possible interval.
      </p>
      <h4>Merge</h4>
      <p>
        Further building on this code we can implement more complex patterns
      </p>
      <p>
        The below function signature represents a module core to this pattern
        that accepts an input of an{" "}
        <span class="code"><a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/for-await...of">AsyncIterable</a></span>
        {" "}that produces zero or more <span class="code">AsyncIterable</span> lanes that produce
        zero or more results
      </p>
      <p>
        The output of the function is a snapshot of the latest value for each
        known async iterable lane or <span class="code">undefined</span>
        if the lane has not yet produced a value
      </p>
      <p>
        Because it utilises the previously detailed{" "}
        <span class="code">resolveNextPromises</span> the batching of results
        happens automatically
      </p>
      <pre>
      {`
export type Lane<T> = AsyncIterable<T>;
export async function *merge<T>(input: AsyncIterable<Lane<T>>, microtask = queueMicrotask): AsyncIterable<T[]>
      `.trim()}
    </pre>
      <p>
        Using this code we can represent a fundamental key in this entire pattern,
        to be able merge sets of updating state together into one unified updating
        state
      </p>
      <p>
        Nodes internally are represented as the following TypeScript interface:
      </p>
      <pre>
      {`
export interface Node {
  children: AsyncIterable<Node[]>
}
    `.trim()}
    </pre>
      <p>
        A fragment node is a node that doesn't represent any state itself, but does contain
        children state, these are a prime example of where we would want to use
        the <span class="code">merge</span> function to create a union of each
        individual fragments children
      </p>
      <p>
        We can utilise <span class="code">merge</span> to transform{" "}
        <span class="code">AsyncIterable&lt;AsyncIterable&lt;Node[]&gt;&gt;</span>{" "}
        into <span class="code">AsyncIterable&lt;Node[]&gt;</span> using the following
        code:
      </p>
      <pre>
      {`
async function* childrenUnion(childrenGroups: AsyncIterable<AsyncIterable<Node[]>>): AsyncIterable<Node[]> {
  for await (const parts of merge(childrenGroups)) {
    yield parts.reduce(
      (updates: Node[], part: (Node | undefined)[]): Node[] => updates.concat((part || []).filter(value => value)),
      []
    );
  }
}
      `.trim()}
      </pre>
    </section>
  </Template>
);
